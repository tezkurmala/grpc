# Protocol Buffers Example in Java

This is a companion repository for my [Protocol Buffers course](http://bit.ly/protocol-buffers-github)

[![course logo](https://i.imgur.com/8fFmWAV.png)](http://bit.ly/protocol-buffers-github)

# Content

- Sample Code
- Proper Gradle Setup
- Few .proto files